package com.bisim.duraklari.Model


import com.google.gson.annotations.SerializedName

// class bisimListResponse{
//    @SerializedName("stations")
//    var stations: List<Station?>? = null
//    @SerializedName("status")
//    var status: String? = null
//
//    data class Station(
//        @SerializedName("BisikletSayisi")
//        var bisikletSayisi: String? = null,
//        @SerializedName("Durumu")
//        var durumu: String? = null,
//        @SerializedName("IstasyonAdi")
//        var istasyonAdi: String? = null,
//        @SerializedName("IstasyonID")
//        var istasyonID: String? = null,
//        @SerializedName("Kapasite")
//        var kapasite: String? = null,
//        @SerializedName("Koordinat")
//        var koordinat: String? = null
//    )
//}

class BisimListResponse : ArrayList<BisimListResponse.BisimListResponseItem>(){
    data class BisimListResponseItem(
        @SerializedName("tur_id")
        var tur_id: String? = null,
        @SerializedName("tur_ad")
        var tur_ad: String? = null
    )
}
