package com.bisim.duraklari.service

import com.bisim.duraklari.Model.BisimListResponse
import io.reactivex.Single
import retrofit2.http.GET
import retrofit2.http.Path

interface bisimAPI {
    companion object{
        const val bisim_duraklar = "gameType"
    }

    @GET
    fun getBisimDuraklarList () : Single<BisimListResponse>

}