package com.bisim.duraklari.service

import com.bisim.duraklari.Model.BisimListResponse
import io.reactivex.Single
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory

class bisimAPIService {
   // val baseURL = "https://openapi.izmir.bel.tr/api/"
    val tempUrl = "https://oyunpuanla.com/game/public/index.php/"
    val retrofit = Retrofit.Builder()
        .baseUrl(tempUrl)
        .addConverterFactory(GsonConverterFactory.create())
        .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
        .build()
        .create(bisimAPI::class.java)

    fun getBisimList() : Single<BisimListResponse>
    {
        return retrofit.getBisimDuraklarList()
    }

}