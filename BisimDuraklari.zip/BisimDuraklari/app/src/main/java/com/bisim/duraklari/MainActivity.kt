package com.bisim.duraklari

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.ListView
import com.bisim.duraklari.view.BisimList
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bt_listele.setOnClickListener {
            val intent = Intent(this,BisimList::class.java)
            startActivity(intent)
        }


    }
}