package com.bisim.duraklari.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bisim.duraklari.R
import kotlinx.android.synthetic.main.bisim_list_item_layout.view.*

class bisimListAdapter : RecyclerView.Adapter<bisimListAdapter.BisimListHolder> (){

    var bisimList: ArrayList<String> = arrayListOf()

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): bisimListAdapter.BisimListHolder = BisimListHolder(LayoutInflater.from(parent.context).inflate(R.layout.bisim_list_item_layout, parent,false))


    override fun onBindViewHolder(holder: bisimListAdapter.BisimListHolder, position: Int) {
        holder.bind(bisimList[position])
    }

    override fun getItemCount(): Int = bisimList.size

    inner class BisimListHolder(view: View) : RecyclerView.ViewHolder(view)
    {
        fun bind(s: String)
        {
            itemView.tv_bisimName.text = s

        }
    }

    fun getData(bisimResponse: ArrayList<String>)
    {
        bisimList.addAll(bisimResponse)
        notifyDataSetChanged()

    }
}