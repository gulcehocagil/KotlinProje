package com.bisim.duraklari.viewModel

import android.annotation.SuppressLint
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.bisim.duraklari.Model.BisimListResponse
import com.bisim.duraklari.service.bisimAPIService
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.observers.DisposableSingleObserver
import io.reactivex.schedulers.Schedulers

class BisimListViewModel : ViewModel(){
    private val BisimAPIService = bisimAPIService()

    val bisimListLivedata: MutableLiveData<BisimListResponse> = MutableLiveData<BisimListResponse>()

    @SuppressLint("CheckResult")
    fun getBisimList()
    {
        BisimAPIService.getBisimList()
            .subscribeOn(Schedulers.newThread())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribeWith(object : DisposableSingleObserver<BisimListResponse>() {
                override fun onSuccess(response: BisimListResponse) {
                    bisimListLivedata.value = response
                }

                override fun onError(e: Throwable) {
                    e.printStackTrace()
                }
            })
    }
}