package com.bisim.duraklari.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.bisim.duraklari.R
import com.bisim.duraklari.adapter.bisimListAdapter
import com.bisim.duraklari.viewModel.BisimListViewModel
import kotlinx.android.synthetic.main.activity_bisim_list.*

class BisimList : AppCompatActivity() {

    private var bisimListViewModel = BisimListViewModel()

    var bisimAdapter = bisimListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bisim_list)

        bisimListViewModel = ViewModelProvider(this).get(BisimListViewModel::class.java)

        bisimListViewModel.getBisimList()

        bisimListViewModel.bisimListLivedata.observe(this, Observer {
            Toast.makeText(applicationContext, it[1].tur_ad, Toast.LENGTH_SHORT).show()
        })

        var bisimList : ArrayList<String> = arrayListOf()
        bisimList.add("Güzel Yalı ")
        bisimList.add("Konak")
        bisimList.add("Bornova")
        bisimList.add("Çeşme")
        bisimList.add("Alaçatı")
        bisimList.add("Kordon Sahil")

        rv_bisimList.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        rv_bisimList.adapter = bisimAdapter
        bisimAdapter.getData(bisimList)

    }
}