package com.bisim.duraklari.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bisim.duraklari.R

class BisimList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bisim_list)
    }
}